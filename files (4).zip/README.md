# 🦠 COVID-19 in India — Exploratory Data Analysis

An end-to-end exploratory data analysis of India's COVID-19 pandemic: state-wise case trends, recovery and death rates, and the national vaccination rollout — built with **NumPy, Pandas, Matplotlib and Seaborn**.

## 📌 Project Overview

| | |
|---|---|
| **Question** | How did COVID-19 spread across Indian states, how did recovery differ, and how did vaccination progress afterwards? |
| **Case data** | [`imdevskp/covid-19-india-data`](https://github.com/imdevskp/covid-19-india-data) — daily state-wise counts, 30 Jan 2020 – 6 Aug 2020 |
| **Vaccination data** | [Our World in Data](https://github.com/owid/covid-19-data) — national totals from 15 Jan 2021 |
| **Output** | 13 charts, cleaned datasets, and an auto-generated written summary |

> The case data covers India's **first wave only** (to Aug 2020). Vaccination data begins in Jan 2021, so the two datasets are treated as two chapters of one story, not as directly comparable series.

## 🗂️ Repository Structure

```
covid19-india-eda/
├── notebooks/
│   └── MiniProject_COVID19_India_EDA.ipynb   # the full analysis
├── data/
│   ├── raw/          # downloaded CSVs are cached here (git-ignored)
│   └── processed/    # cleaned datasets written by the notebook
├── images/           # all 13 charts saved as PNG by the notebook
├── requirements.txt
├── .gitignore
├── LICENSE
└── README.md
```

## 🚀 Getting Started

```bash
# 1. Clone
git clone https://github.com/<your-username>/covid19-india-eda.git
cd covid19-india-eda

# 2. (Optional) create a virtual environment
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Launch the notebook and choose "Run All"
jupyter notebook notebooks/MiniProject_COVID19_India_EDA.ipynb
```

The first run downloads the data (internet needed); later runs use the cached copy in `data/raw/`. Charts are saved to `images/` and cleaned data to `data/processed/`.

## 🧹 Data Cleaning

| Problem found | Fix |
|---|---|
| `Death` column stored as text (stray characters) | `pd.to_numeric(errors="coerce")` → integer |
| One state under many spellings (`Telangana`, `Telengana`, `Telangana***`) | Strip footnote asterisks + name-mapping dictionary |
| UTs listed twice (`Ladakh` and `Union Territory of Ladakh`, etc.) | Merged under a single name |
| Duplicate `(date, state)` rows created by merging | `drop_duplicates` |
| Inconsistent column names | Renamed to `snake_case` |

After cleaning: 40 raw names → **35 states/UTs**, 4,692 rows, no missing values.

## 📊 Charts

| # | Chart | # | Chart |
|---|---|---|---|
| 1 | National cumulative trend | 8 | Recovery vs death rate (bubble) |
| 2 | Daily new cases + 7-day average | 9 | Correlation heatmap |
| 3 | Top 10 states by cases | 10 | Monthly spread of daily cases (boxplot) |
| 4 | Recovery rate, top 10 states | 11 | Vaccination: cumulative + daily doses |
| 5 | Top 5 states over time | 12 | 10 least-affected states/UTs |
| 6 | Share of national cases (pie) | 13 | Monthly new-cases heatmap by state |
| 7 | National recovery-rate trend | | |

After running the notebook, the images are in [`images/`](images/).

## 🔍 Key Findings (as of 6 Aug 2020)

- **~19.6 lakh** confirmed cases, **~13.3 lakh** recoveries, **~40,700** deaths → recovery rate **≈ 67.6%**, death rate **≈ 2.07%**.
- Daily new cases were still running at roughly **52,000–56,000 per day** at the end of the window, so the first wave had not yet crested.
- **Maharashtra** alone accounted for close to a quarter of national cases; with **Tamil Nadu, Andhra Pradesh, Karnataka and Delhi** it formed the top five.
- **Delhi** had the highest recovery rate among the worst-hit states (≈ 90%); **Karnataka** the lowest (≈ 49%).
- **Gujarat** had the highest death rate among the worst-hit states (≈ 3.8%).
- Vaccination began Jan 2021; by mid-2024 over **2.2 billion** doses had been administered and **950+ million** people were fully vaccinated.

*The notebook's final section regenerates these numbers directly from the data.*

## ⚠️ Limitations

- Data is compiled from state bulletins and inherits reporting inconsistencies.
- Recovery and death rates are simple ratios of cumulative totals — not adjusted for reporting lag, testing intensity or demographics.
- Cases are **not** normalised by population.

## 🔭 Possible Next Steps

- Per-million-population rates for fair state comparisons
- Doubling-time / growth-rate modelling
- Extend to second-wave data (2021)
- Interactive dashboard (Plotly / Streamlit)

## 🛠️ Tech Stack

Python · NumPy · Pandas · Matplotlib · Seaborn · Jupyter

## 📄 License

Released under the [MIT License](LICENSE). Data belongs to its original publishers (see sources above).
